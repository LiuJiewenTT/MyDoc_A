# New Liquid Docs

To run, follow these steps:

1. [Download and install Ruby](https://www.ruby-lang.org/en/downloads)
2. Download ZIP or clone in GitHub
3. Navigate to `liquid-gh-pages` folder or checkout `gh-pages` branch
4. Run `gem install bundler`
5. Run `bundle install`
6. Run `bundle exec jekyll serve`
7. Open [`http://127.0.0.1:4000/liquid/`](http://127.0.0.1:4000/liquid/) in your browser
